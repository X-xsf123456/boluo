// pages/bianlian/bianlian.js

function createRandomIndex(){
  return Math.floor(Math.random()*10);
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:0,
    imgArr :[
      '/images/01.jpg',
      '/images/02.jpg',
      '/images/03.jpg',
      '/images/04.jpg',
      '/images/05.jpg',
      '/images/06.jpg',
      '/images/07.jpg',
      '/images/08.jpg',
      '/images/09.jpg',
      '/images/010.jpg',
      
    ],
  },

  changeFace:function(){
    this.setData({
      index:createRandomIndex()
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    var that = this;
    wx.onAccelerometerChange(function(res){
      if(res.x>0.5||res.y>0.5||res.z>0.5){
        wx.showToast({
          title:'摇一摇成功',
          icon:'success',
          duration:2000
        })
        that.changeFace()
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})