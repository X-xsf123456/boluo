// pages/canvas/canvas.js
Page({
  onLoad :function (options) {
    this.drawtriangle();
  },
  drawtriangle:function()
  {
    const ctx = wx.createCanvasContext('my')
    ctx.beginPath();
    ctx.moveTo(200,400);
    ctx.arc(250,350,70,Math.PI/4,Math.PI,true);
    ctx.arc(350,350,70,Math.PI/4,Math.PI,true);
    
    ctx.lineTo(200,400);
    ctx.lineTo(300,300);
    ctx.lineTo(400,400);
    ctx.lineTo(300,500);
    ctx.setStrokeStyle('red');//线
    ctx.closePath();
    ctx.fillStyle="red";
    ctx.fill();
    ctx.stroke();
    ctx.draw(true);
  },
  
})