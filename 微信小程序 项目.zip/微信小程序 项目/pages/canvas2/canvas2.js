// pages/canvas2/canvas2.js
Page({
  onLoad :function (options) {
    const ctx = wx.createCanvasContext('my')
    var dx = 150;
    var dy = 150;
    var s =100;
    ctx.beginPath();
    var x = Math.sin(0);
    var y = Math.cos(0);
    var dig = Math.PI / 15*11;
    for(var i=0;i<30;i++){
      var x = Math.sin(i*dig);
      var y = Math.cos(i*dig);
      ctx.lineTo(dx+x*s, dy+y*s);
    }
    ctx.closePath();
    ctx.stroke();
    ctx.draw(true);


  },
  /**
   * 页面的初始数据
   */
  
})