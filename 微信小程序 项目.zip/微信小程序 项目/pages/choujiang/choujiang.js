// pages/choujiang/choujiang.js

var angel = 0;

Page({

  
  /**
   * 页面的初始数据
   */
  data: {
    lotteryNum:3,
    score:5
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady:function() {
    this.animation = wx.createAnimation({
      duration:2800,
      timingFunction:'ease',
      delay:100
    })
  },

  rotate:function(){
    if(this.data.lotteryNum){
      angel = Math.abs(Math.random()*720+1080)
      this.animation.rotate(angel).step()
      this.setData({
        animation:this.animation.export(),
        lotteryNum:this.data.lotteryNum - 1
      })
      this.result()
    } else{
        var score = this.data.score
        var jiang = ''
        if (score==0) jiang = '特等奖'
        else if(score==1) jiang = '一等奖'
        else if(score==2) jiang = '二等奖'
        else if(score==4) jiang = '三等奖'
        else if(score==4) jiang = '四等奖'
        else if(score==5) jiang = '谢谢参与'
        wx.showToast({
          title: '没有抽奖机会了~，你最终的等奖是：'+jiang,
          icon : 'none'
        })
    }
  },

  result: function(e) {
    do{
        angel = angel - 360
    }while (angel>360)
    var that = this
    setTimeout(function(){
        var score;
        if (angel<=30 || angel>330){
            wx.showModal({
              title: '恭喜你',
              content: '特等奖',
            })
            score=0
        }else if(angel>30 && angel<=90){
            wx.showModal({
                title: '很遗憾',
                content: '谢谢参与',
              })
              score=5
        }else if(angel>90 && angel<=150){
            wx.showModal({
                title: '恭喜你',
                content: '四等奖',
              })
              score=4
        }else if(angel>150 && angel<=210){
            wx.showModal({
                title: '恭喜你',
                content: '三等奖',
              })
              score=3
        }else if(angel>210 && angel<=270){
            wx.showModal({
                title: '恭喜你',
                content: '二等奖',
              })
              score=2
        }else if(angel>270 && angel<=330){
            wx.showModal({
                title: '恭喜你',
                content: '一等奖',
              })
              score=1
        }
        if (score<that.data.score){
            that.data.score = score
            console.log(score)
        }
    },3000)
  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})