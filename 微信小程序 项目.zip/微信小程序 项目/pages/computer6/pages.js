// pages/computer/pages.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    iconColor: [
      'red','orange','yellow','green','rgb(0,255,255)','blue','purple'
    ],
    iconStyle: [
      {"type":"success",
      "size":"30",
      "color":"#32CD32"
    },
      {"type":"success_no_circle",
      "size":"30",
      "color":"orange"
    },
      {"type":"info",
      "size":"30",
      "color":"yellow"
    },
      {"type":"warn",
      "size":"30",
      "color":"green"
    },
      {"type":"waiting",
      "size":"30",
      "color": "rgb(0,255,255)"
    },
      {"type":"cancel","size":"30","color":"blue"},
      {"type":"download","size":"30","color":"purple"},
      {"type":"search","size":"30","color":"#C4C4C4"},
      {"type":"clear","size":"30","color":"red"}
    ]



  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})