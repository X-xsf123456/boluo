// index.js
Page({
  data: {
    answer: 0,       // 正确答案
    inputNum: '',    // 输入的数字
    tipText: '开始游戏！请猜1-100之间的数字',
    guessCount: 0    // 猜测次数
  },

  // 页面加载时生成随机数
  onLoad() {
    this.initGame();
  },

  // 初始化游戏
  initGame() {
    // 生成 1~100 随机整数
    const answer = Math.floor(Math.random() * 100) + 1;
    this.setData({
      answer: answer,
      guessCount: 0,
      inputNum: '',
      tipText: '游戏开始！请猜1-100之间的数字'
    });
    console.log('答案：', answer); // 开发时可看答案
  },

  // 监听输入框
  onInput(e) {
    this.setData({
      inputNum: e.detail.value
    });
  },

  // 点击猜一猜
  onGuess() {
    let { inputNum, answer, guessCount } = this.data;

    // 空值判断
    if (!inputNum) {
      this.setData({ tipText: '请输入数字哦！' });
      return;
    }

    let num = parseInt(inputNum);
    // 数字范围判断
    if (num < 1 || num > 100) {
      this.setData({ tipText: '只能输入1-100的数字！' });
      return;
    }

    // 猜测次数+1
    guessCount++;
    let tip = '';

    // 判断大小
    if (num > answer) {
      tip = '❌ 太大了，再小一点';
    } else if (num < answer) {
      tip = '❌ 太小了，再大一点';
    } else {
      tip = `🎉 恭喜你猜对了！答案就是 ${answer}`;
    }

    this.setData({
      tipText: tip,
      guessCount: guessCount
    });
  },

  // 重新开始
  restart() {
    this.initGame();
  }
});