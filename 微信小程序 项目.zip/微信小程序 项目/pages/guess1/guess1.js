// pages/guess1/guess1.js

var guessnum = "";
var n = 0;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    result: '',
    allresult: '',
    num:0
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.num = Math.floor(Math.random() * 100);
    console.log('随机生成数字为'+ this.num)
  },

  numcompare: function(e) {
    var x = Number(e.detail.value);
    guessnum = guessnum + " " + e.detail.value;
    n++;
    if (n>10) {
      wx.showToast({
        title: '游戏结束，重新开始',
      })
      return;
    } 
    console.log(x);
    var str = '两个数相等';
    if (x>this.num) {
      str ='猜大了';
    } else if (x<this.num){
      str ='猜小了';
    } else 
      str = '对了';
    console.log(str)
    this.setData({
      result:str,
      allresult:guessnum,
    })
  },

  newgame: function(e) {
    n=0;
    guessnum = " ";
    this.num = Math.floor(Math.random()*100);
    console.log('发生的方式'+this.num)
    this.setData({
      result:'',
      allresult: '',
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})