// pages/paobudonghua/paobudonghua.js
var x=300;
var n=0;


Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad:function() {
    this.init();
  },
  init:function(){
    setInterval(this.draw,100);
  },


  draw:function(){
    var ctx = wx.createCanvasContext('myCanvas')
    ctx.clearRect(0,0,300,300);
    ctx.drawImage('/image/people.jpg',60*n,0,60,80,x,0,60,80);
    if(n>=8){
      n=0;
    } else {
      n++;
    }
    if(x>=0){
      x=x-30;
    } else {
      x=300;
    }
    ctx.draw();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})