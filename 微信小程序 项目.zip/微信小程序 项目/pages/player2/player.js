// pages/player/player.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    computerHand: '?', // 电脑出拳
    result: '请出拳',   // 结果
    resultClass: ''    // 结果颜色样式
  },

  play(e) {
    const player = e.currentTarget.dataset.hand; // 获取玩家选择
    const hands = ['✊', '✋', '✌️'];
    const computer = hands[Math.floor(Math.random() * 3)]; // 电脑随机出拳

    let result = '';
    let resultClass = '';

    // 判断胜负
    if (player === computer) {
      result = '平局';
      resultClass = 'draw';
    } else if (
      (player === '✊' && computer === '✋') ||
      (player === '✋' && computer === '✌️') ||
      (player === '✌️' && computer === '✊')
    ) {
      result = '你赢了';
      resultClass = 'win';
    } else {
      result = '你输了';
      resultClass = 'lose';
    }

    // 更新页面数据
    this.setData({
      computerHand: computer,
      result,
      resultClass
    });
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})