// pages/shujuhuancun/setStorage.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    flag:true,
    name:'',
    password:'',
  },

  nameInput:function(e){
    this.setData({
      name:e.detail.value
    });
  },


  passInput:function(e){
    this.setData({
      password:e.detail.value
    });
  },


  mysubmit:function(){
    if(this.data.name==""|| this.data.password==""){
      wx.showToast({
        title: '信息输入不全',
        icon: "success"
      })
    } else{
      
      this.setStorage();
    }
  },

  setStorage:function(e) {
    let key= this.data.name;
    wx.setStorage({
      key:key,
      data:this.data.password
    })
  },



  getStorage:function(e){
    if(this.data.name == ''){
      wx.showToast({
        title:"请输入用户名",
        icon:"loading"
      })
      return;
    }
    var that = this;
    let key = this.data.name;
    wx.getStorage({
      key:key,
      success:function(res){
        console.log(res.data)
        that.setData({
          password:res.data,
          flag:false
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})