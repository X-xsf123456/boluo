//手指按下的坐标
var startx = 0;
var starty = 0;

//手指在Canvas移动时的坐标
var movex = 0;
var movey = 0;
var direction = 'right';
var score = 0; //游戏得分
//方向
var sankeDirection = 'right';
//蛇头对象
var snakeHead = {
  x: 0,
  y: 0,
  color: "#ff0000",
  w: 20,
  h: 20
}
// 差值
var x = 0;
var y = 0;

//蛇身
var snakeBody = [];
var one = null;
var foods = [];
var W=15;  //游戏场地大小宽度和高度
var H=25;
function collide(obj1, obj2) {
  var l1 = obj1.x;
  var r1 = l1 + obj1.w;
  var t1 = obj1.y;
  var b1 = t1 + obj1.h;

  var l2 = obj2.x;
  var r2 = l2 + obj2.w;
  var t2 = obj2.y;
  var b2 = t2 + obj2.h;

  if (r1 > l2 && l1 < r2 && b1 > t2 && t1 < b2)
    return true;
  else
    return false;
}
//蛇碰到食物
function collide2(obj1, obj2) {
  var l1 = obj1.x;
  var t1 = obj1.y;
  var l2 = obj2.x;
  var t2 = obj2.y;
  if (l1 == l2 && t1 == t2)
    return true;
  else
    return false;
}

Page({

  data: {
    timer: '', //定时器 
  },

  touchStart: function(e) {
    startx = e.touches[0].x;
    starty = e.touches[0].y;
    /*this.setData({
      startx: startx,
      starty: starty
    })
    */
  },
  touchMove: function(e) {
    movex = e.touches[0].x;
    movey = e.touches[0].y;
    x = movex - startx;
    y = movey - starty;
  },
  touchEnd: function() {
    console.log(x);
    console.log(y);
    if (Math.abs(x) > Math.abs(y) && x > 0) {
      direction = 'right';
      console.log('right');
    } else if (Math.abs(x) > Math.abs(y) && x < 0) {
      direction = 'left';
      console.log('left');
    } else if (Math.abs(x) < Math.abs(y) && y < 0) {
      direction = 'up';
      console.log('up');
    } else {
      direction = 'down';
      console.log('down');
    }
    sankeDirection = direction;
    //this.move();
  },

  //移动函数
  move: function() {
    var that=this;    
    this.data.timer = setInterval(function() {
      //获取画布的上下文
      var context = wx.createCanvasContext('snakeCanvas', this);
      switch (sankeDirection) {
        case "left":
          snakeHead.x -= 20;
          break;
        case "right":
          snakeHead.x += 20;
          break;
        case "up":
          snakeHead.y -= 20;
          break;
        case "down":
          snakeHead.y += 20;
          break;
      }
      if (snakeHead.x > W * 20 || snakeHead.y > H * 20 ||
        snakeHead.x < 0 || snakeHead.y < 0) {
        clearInterval(that.data.timer);
        wx.showModal({
          title: '提示',
          content: "游戏结束！你的得分是" + score,
          success: function (res) {
            if (res.confirm) {
              console.log('用户点击确定')      
              that.newGame();//重新开始
            } else if (res.cancel) {
              console.log('用户点击取消');              
            }
          }
        });
        console.log("游戏结束！你的得分是" + score);
      }
      snakeBody.push({
        x: snakeHead.x,
        y: snakeHead.y,
        w: 20,
        h: 20,
        color: "#00ff00"   //绿色
      })
      var collideBoolean = false;

      //是否碰到食物
      for (var i = 0; i < foods.length; i++) {
        one = foods[i]
        if (collide2(snakeHead, foods[i])) {
          collideBoolean = true;
          foods.splice(i, 1); //删除碰到食物
          console.log("碰到食物foods[i].x");
          console.log(one.x);
          score+=10;
          that.creatFood();
        }
      }
      if (snakeBody.length > 3 && collideBoolean == false) {
        snakeBody.shift(); //删去首元素（蛇尾）
      }
      //绘制蛇身
      for (var i = 0; i < snakeBody.length-1; i++) {
        var one = snakeBody[i]; //一节蛇身
        context.setFillStyle(one.color);
        context.beginPath();
        context.rect(one.x, one.y, one.w, one.h);
        context.closePath();
        context.fill();
      }
      //绘制蛇头
      context.setFillStyle(snakeHead.color);
      context.beginPath();
      context.rect(snakeHead.x, snakeHead.y, snakeHead.w, snakeHead.h);
      context.closePath();
      context.fill();

      //绘制食物
      for (var i = 0; i < foods.length; i++) {
        var one = foods[i]; //一个食物
        context.setFillStyle("#0000ff");
        context.beginPath();
        context.rect(one.x, one.y, one.w, one.h);
        context.closePath();
        context.fill();
      }
      context.draw();
    }, 600)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var m1 = wx.getSystemInfoSync().screenWidth;
    W = Math.floor(m1 / 20 ) ;
    var m2 = wx.getSystemInfoSync().screenHeight;
    H = Math.floor(m2 / 20) - 4;  //screenHeight含有有标题栏高度
    console.log(m1 + ":" + m2);
    console.log(W+":"+H);    //16：24
    for (var i = 0; i < 20; i++) {
      this.creatFood();
    }
    this.move();
  },
  newGame: function (options) {
    snakeBody = [];  //清空蛇身
    foods = [];      //清空食物
    for (var i = 0; i < 20; i++) {
      this.creatFood();
    }
    snakeHead.x = 100;
    snakeHead.y = 100;
    this.move();

  },
  //生成食物构造函数
  creatFood: function() {
    //系统信息
    var x = Math.floor(Math.random() * W) * 20;
    var y = Math.floor(Math.random() * H) * 20;
    var w = 20;
    var h = 20;
    var color = "#0000ff";
    foods.push({
      x: x,
      y: y,
      w: 20,
      h: 20,
      color: color
    })
  },
})
